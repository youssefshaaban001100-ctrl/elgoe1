import express from 'express';import cors from 'cors';import multer from 'multer';import XLSX from 'xlsx';
const app=express(), upload=multer({dest:'uploads/'}); app.use(cors());app.use(express.json());
const OWNER_TOKEN=process.env.EL_JOE_OWNER_TOKEN||'CHANGE_ME';
function owner(req,res,next){if(req.headers['x-owner-token']!==OWNER_TOKEN)return res.status(403).send('Owner only');next();}
app.get('/health',(req,res)=>res.json({ok:true,name:'EL JOE'}));
app.post('/admin/import-excel',owner,upload.single('file'),(req,res)=>{if(!req.file)return res.status(400).send('No Excel file');const wb=XLSX.readFile(req.file.path);const ws=wb.Sheets[wb.SheetNames[0]];const rows=XLSX.utils.sheet_to_json(ws,{defval:''});/* production: validate, normalize, deduplicate, then write to Firestore/SQL */res.json({ok:true,rows:rows.length,message:'Excel parsed successfully; connect persistence before production.'});});
app.post('/admin/publish',owner,(req,res)=>{const {version,downloadUrl}=req.body||{};if(!version||!downloadUrl)return res.status(400).send('version and downloadUrl required');res.json({ok:true,version,downloadUrl,message:'Publish metadata accepted; connect Firestore/hosting in production.'});});
app.listen(process.env.PORT||3000,()=>console.log('EL JOE backend running'));
