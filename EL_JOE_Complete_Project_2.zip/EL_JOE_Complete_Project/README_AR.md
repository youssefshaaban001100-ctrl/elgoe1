# EL JOE — مشروع مساعد الصيدلي

هذا المشروع هو الهيكل الكامل المقترح لـ EL JOE:
- تطبيق Android للمستخدمين.
- لوحة Admin للمالك فقط.
- قاعدة أدوية مركزية.
- استيراد Excel من لوحة المالك.
- ربط حساب المستخدم بجهاز واحد.
- فحص إصدار التطبيق وتحديثه من الموقع.
- صلاحيات Owner/User.
- بحث فوري من أول حرف.
- دعم قاعدة بيانات محلية للعمل السريع Offline.

## مهم قبل الإنتاج
هذه الحزمة هي **مشروع جاهز للتطوير والبناء** وليست APK منشورًا ولا سيرفرًا مستضافًا. لا يمكن من داخل المحادثة إنشاء حساب Firebase/دومين أو نشر Backend نيابة عنك.

## التشغيل
### تطبيق Android
يتطلب Flutter SDK وAndroid Studio:
```bash
cd mobile
flutter pub get
flutter run
```

### لوحة الإدارة
```bash
cd admin-web
python -m http.server 8080
```
ثم افتح:
`http://localhost:8080`

### Backend
موجود كـ Node/Express starter في مجلد backend، ويحتاج Node.js:
```bash
cd backend
npm install
npm start
```

## الإنتاج
1. أنشئ Firebase Project باسم EL JOE.
2. فعّل Authentication.
3. فعّل Firestore.
4. ضع إعدادات Firebase في mobile/lib/firebase_options.dart.
5. اضبط قواعد Firestore من firestore.rules.
6. استضف backend وadmin-web على دومينك.
7. ارفع APK/AAB إلى استضافة الإصدارات.
8. غيّر API_BASE_URL وDOWNLOAD_URL في التطبيق.

**لا تضع مفاتيح Admin أو أسرار السيرفر داخل تطبيق Android.**
