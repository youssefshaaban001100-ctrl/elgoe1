## قاعدة بيانات EL JOE
الحقول المقترحة:
- tradeName
- scientificName
- activeIngredient
- drugType
- dosageForm
- strength
- uses
- price
- manufacturer
- country
- agent
- registrationNumber
- authorizationStatus
- marketingStatus
- atc
- barcode
- storage
- package
- updatedAt

ملف Excel يستطيع استخدام هذه العناوين. ويمكن إضافة أعمدة SFDA الأخرى دون حذفها.
