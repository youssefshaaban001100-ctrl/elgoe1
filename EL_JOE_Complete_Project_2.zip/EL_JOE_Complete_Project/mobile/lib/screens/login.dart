import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'home.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState()=>_LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen>{
  final user=TextEditingController(), pass=TextEditingController();
  bool loading=false;
  Future<void> login() async {
    setState(()=>loading=true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email:user.text.trim(), password:pass.text);
      if(mounted) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomeScreen()));
    } catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content:Text('بيانات الدخول غير صحيحة أو الحساب غير مفعل')));
    } finally { if(mounted)setState(()=>loading=false); }
  }
  @override Widget build(BuildContext c)=>Scaffold(
    body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(
      children:[
        const Text('EL JOE',style:TextStyle(fontSize:38,fontWeight:FontWeight.w900,color:Color(0xFF10A85B))),
        const Text('Saudi Pharmacy Assistant'),
        const SizedBox(height:35),
        TextField(controller:user,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'اسم المستخدم / البريد',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'كلمة السر',border:OutlineInputBorder())),
        const SizedBox(height:18),
        SizedBox(width:double.infinity,height:52,child:FilledButton(onPressed:loading?null:login,child:Text(loading?'جاري الدخول...':'تسجيل الدخول')))
      ],
    )))
  );
}
