import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeState(); }
class _HomeState extends State<HomeScreen>{
  final q=TextEditingController(); List<Map<String,dynamic>> results=[]; bool loading=false;
  Future<void> search(String text) async {
    if(text.trim().isEmpty){setState(()=>results=[]);return;}
    setState(()=>loading=true);
    // Production: query the local SQLite FTS index first, then optionally sync.
    final snap=await FirebaseFirestore.instance.collection('drugs')
      .orderBy('tradeName').limit(50).get();
    final n=text.toLowerCase();
    final list=snap.docs.map((d)=>d.data()).where((d){
      final s='${d['tradeName']??''} ${d['scientificName']??''} ${d['activeIngredient']??''}'.toLowerCase();
      return s.contains(n);
    }).toList();
    setState(()=>results=list.cast<Map<String,dynamic>>()); setState(()=>loading=false);
  }
  Future<void> checkUpdate() async {
    final p=await PackageInfo.fromPlatform();
    final doc=await FirebaseFirestore.instance.collection('config').doc('app').get();
    final latest=doc.data()?['latestVersion'];
    final url=doc.data()?['downloadUrl'];
    if(mounted && latest!=null && latest!=p.version && url!=null) {
      showDialog(context:context,builder:(_)=>AlertDialog(
        title:const Text('تحديث جديد متاح'),
        content:Text('الإصدار الحالي ${p.version}\\nالإصدار الجديد $latest'),
        actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('لاحقًا')),
          FilledButton(onPressed:()=>launchUrl(Uri.parse(url)),child:const Text('تحديث الآن'))]));
    } else if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('أنت تستخدم أحدث إصدار')));
  }
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('EL JOE'),actions:[IconButton(onPressed:checkUpdate,icon:const Icon(Icons.system_update))]),
    body:Padding(padding:const EdgeInsets.all(14),child:Column(children:[
      TextField(controller:q,onChanged:search,decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'ابحث من أول حرف...',border:OutlineInputBorder())),
      const SizedBox(height:12),
      if(loading)const LinearProgressIndicator(),
      Expanded(child:ListView.builder(itemCount:results.length,itemBuilder:(c,i){
        final d=results[i]; return Card(child:ListTile(title:Text('${d['tradeName']??''}'),subtitle:Text('${d['scientificName']??''}\\n${d['strength']??''} • ${d['dosageForm']??''}'),isThreeLine:true,onTap:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:Text('${d['tradeName']??''}'),content:Text('المادة الفعالة: ${d['activeIngredient']??'—'}\\nالنوع: ${d['drugType']??'—'}\\nالصنف: ${d['dosageForm']??'—'}\\nالاستخدام: ${d['uses']??'—'}\\nالسعر: ${d['price']??'—'}'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إغلاق'))])));}))
    ])));
}
