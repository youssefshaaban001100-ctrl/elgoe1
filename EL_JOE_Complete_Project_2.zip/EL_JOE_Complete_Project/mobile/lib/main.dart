import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/login.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const ElJoeApp());
}

class ElJoeApp extends StatelessWidget {
  const ElJoeApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EL JOE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF10A85B)),
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}
